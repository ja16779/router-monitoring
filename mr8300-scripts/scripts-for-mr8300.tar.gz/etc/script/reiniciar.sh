#!/bin/sh

#TOKEN="6488210393:AAFExiQfMZMzhbuq1jJIcHNOxvMG6et5iU0"
TOKEN="8054647573:AAE_u741UvHjf4ZcsxbTbq1e9eMdtIOBkz8"
ID="716542586"
URL="https://api.telegram.org/bot$TOKEN/sendMessage"
MENSAJE="Router Reiniciado at $(date)"
curl -s -X POST $URL -d chat_id=$ID -d text="$MENSAJE" > /dev/null
ntpdate 0.openwrt.pool.ntp.org
sleep 30
/etc/init.d/qosmate start
opkg update
