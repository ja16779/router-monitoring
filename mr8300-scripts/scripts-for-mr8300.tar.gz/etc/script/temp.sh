#!/bin/sh

# Threshold temperature in Celsius
THRESHOLD=65

# Telegram Bot Token and Chat ID
#TOKEN="6488210393:AAFExiQfMZMzhbuq1jJIcHNOxvMG6et5iU0"
TOKEN="8054647573:AAE_u741UvHjf4ZcsxbTbq1e9eMdtIOBkz8"
ID="716542586"
URL="https://api.telegram.org/bot$TOKEN/sendMessage"

# Check the current temperature
TEMP=$(cat /sys/class/thermal/thermal_zone0/temp)
TEMP_C=$(($TEMP / 1000))

# Compare with the threshold and send a notification if necessary
if [ "$TEMP_C" -gt "$THRESHOLD" ]; then
    echo "Warning! Temperature is above ${THRESHOLD}°C: ${TEMP_C}°C"
    MENSAJE="Warning! Temperature is above ${THRESHOLD}°C: ${TEMP_C}°C on $(uname -n)"
    curl -s -X POST $URL -d chat_id=$ID -d text="$MENSAJE" > /dev/null
fi

