#!/bin/sh

# Threshold temperature in Celsius
THRESHOLD=65

# Telegram Bot Token and Chat ID
#TOKEN="6488210393:AAFExiQfMZMzhbuq1jJIcHNOxvMG6et5iU0"
TOKEN="8054647573:AAE_u741UvHjf4ZcsxbTbq1e9eMdtIOBkz8"
ID="716542586"
URL="https://api.telegram.org/bot$TOKEN/sendMessage"

# Check the current temperature
MESSAGE=$(iwinfo | grep Tx-Power)

# Compare with the threshold and send a notification if necessary
    curl -s -X POST $URL -d chat_id=$ID -d text="$MESSAGE" > /dev/null
