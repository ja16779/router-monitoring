#!/bin/sh
# === CONFIGURACION DE MONITOREO ===

# Umbrales
UMBRAL_CPU=80
UMBRAL_RAM=85
UMBRAL_DISCO=90
UMBRAL_TEMP=70
UMBRAL_LATENCIA=100
UMBRAL_CONEXIONES=500
UMBRAL_SSH_INTENTOS=5

# Red
INTERFAZ_WAN="wan"
HOSTS_PING="8.8.8.8 1.1.1.1"

# Servicios a monitorear
SERVICIOS_CRITICOS="adguardhome dnsmasq dropbear odhcpd"

# Telegram - EDITAR ESTOS VALORES
TELEGRAM_ACTIVO=1
TELEGRAM_BOT_TOKEN="8054647573:AAE_u741UvHjf4ZcsxbTbq1e9eMdtIOBkz8"
TELEGRAM_CHAT_ID="716542586"

# Archivos
ARCHIVO_DISPOSITIVOS_CONOCIDOS="/etc/monitor/dispositivos_conocidos.txt"

# Función para enviar mensajes a Telegram CON PREFIJO
send_telegram() {
    local MESSAGE="$1"
    local TOPIC="${2:-LOG}"
    
    [ -z "$TELEGRAM_BOT_TOKEN" ] || [ -z "$TELEGRAM_CHAT_ID" ] && return 0
    [ "$TELEGRAM_ACTIVO" != "1" ] && return 0
    
    # Agregar prefijo [TOPIC] si se proporciona
    if [ -n "$TOPIC" ]; then
        MESSAGE="[$TOPIC] $MESSAGE"
    fi
    
    # Escapar caracteres especiales para Telegram
    MESSAGE=$(echo "$MESSAGE" | sed 's/\&/\&amp;/g' | sed 's/</\&lt;/g' | sed 's/>/\&gt;/g')
    
    curl -s -X POST \
        "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage" \
        -H 'Content-Type: application/json' \
        -d "{\"chat_id\":\"${TELEGRAM_CHAT_ID}\",\"text\":\"${MESSAGE}\",\"parse_mode\":\"HTML\"}" \
        > /dev/null 2>&1
}
TOKEN="6488210393:AAFExiQfMZMzhbuq1jJIcHNOxvMG6et5iU0"
CHAT_ID="716542586"
